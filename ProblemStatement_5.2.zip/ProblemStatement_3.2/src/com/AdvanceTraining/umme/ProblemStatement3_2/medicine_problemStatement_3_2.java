package com.AdvanceTraining.umme.ProblemStatement3_2;


public class medicine_problemStatement_3_2{public void displayLabel(){System.out.println("Company : Globex Pharma");System.out.println("Address : Bangalore");}}class Tablet extends medicine_problemStatement_3_2{
	 
public void displayLabel(){System.out.println("store in a cool dry place");}}class Syrup extends medicine_problemStatement_3_2{public void displayLabel(){System.out.println("Consumption as directed by thephysician");}}class Ointment extends medicine_problemStatement_3_2{public void displayLabel(){System.out.println("for external use only");

}

}