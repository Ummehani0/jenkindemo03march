package com.AdvanceTraining.umme.ProblemStatement1_4;
import java.util.Scanner;
public class Rectangle {
	int length; 
    int width; 
    int area; 
    int parameter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	
    public Rectangle()
    {
    	length = 1;
    	width= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter width of rectangle: ");
        width = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * width;
       
    }
 
     void  perimeterRectangle()
    {
    	 parameter = 2*(length + width);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +parameter);}
       
        }

    public static void main(String args[]) {
    	
        Rectangle rectangle1 = new Rectangle();
        rectangle1.input();
        rectangle1.areaRectangle();
        rectangle1.perimeterRectangle();
        rectangle1.display();
        System.out.println("______________________________________");
        Rectangle rectangle2 = new Rectangle();
        rectangle2.input();
        rectangle2.areaRectangle();
        rectangle2.perimeterRectangle();
        rectangle2.display();
        System.out.println("______________________________________");
        Rectangle obj3 = new Rectangle();
        obj3.input();
        obj3.areaRectangle();
        obj3.perimeterRectangle();
        obj3.display();
        System.out.println("______________________________________");
        Rectangle rectangle4 = new Rectangle();
        rectangle4.input();
        rectangle4.areaRectangle();
        rectangle4.perimeterRectangle();
        rectangle4.display();
        System.out.println("______________________________________");
        Rectangle rectangle5 = new Rectangle();
        rectangle5.input();
        rectangle5.areaRectangle();
        rectangle5.perimeterRectangle();
        rectangle5.display();
    	
    }
}