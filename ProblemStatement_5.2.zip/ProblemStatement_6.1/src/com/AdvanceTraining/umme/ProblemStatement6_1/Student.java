package com.AdvanceTraining.umme.ProblemStatement6_1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class Student {
	 public static void main (String[] args) {
		 ArrayList<String> a1=new ArrayList<String>();
	 int n;
	 Scanner scanner= new Scanner(System.in);
	 System.out.println("Enter the number of students:");
	 n=scanner.nextInt();
	 System.out.println("Enter the student names:");
	for(int i=0;i<n;i++)
	{
		a1.add(scanner.next());
	}
	System.out.println("student list:");
	for(String a:a1)
	{
			System.out.println("Enter the name of the student to be searched:");
		    String string1=scanner.next(); 
		    int position=Collections.binarySearch(a1,string1);
		   
			System.out.println("posistion of"+string1+"is:"+position);
		    
			}
	 }
	 }