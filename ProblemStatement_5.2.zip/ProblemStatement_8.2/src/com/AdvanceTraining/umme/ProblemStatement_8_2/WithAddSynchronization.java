package com.AdvanceTraining.umme.ProblemStatement_8_2;

public class WithAddSynchronization {
	public static void main(String[] args) {
		Working_on_Storage st = new Working_on_Storage();
		Working_On_Counter c = new Working_On_Counter(st);
		Working_on_Printer p = new Working_on_Printer(st);
		new Thread(c, "Counter").start();
		new Thread(p, "Printer").start(); 
	}

}
