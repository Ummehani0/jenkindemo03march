package com.AdvanceTraining.umme.ProblemStatement_3_1;

public class Flute {
	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}