package com.AdvanceTraining.umme.ProblemStatement_3_1;

public class Guitar {
	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}