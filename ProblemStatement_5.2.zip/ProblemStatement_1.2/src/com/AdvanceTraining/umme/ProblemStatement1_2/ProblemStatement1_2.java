package com.AdvanceTraining.umme.ProblemStatement1_2;
import java.util.Scanner;
public class ProblemStatement1_2 {
	int length; 
    int breadth; 
    int area; 
   
    public ProblemStatement1_2()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Please Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Please Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("The Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) {
        ProblemStatement1_2 problemStatement1_21 = new ProblemStatement1_2();
        problemStatement1_21.input();
        problemStatement1_21.calculate();
        problemStatement1_21.display();
        System.out.println("____________________________________");
        ProblemStatement1_2 problemStatement1_22 = new ProblemStatement1_2();
        problemStatement1_22.input();
        problemStatement1_22.calculate();
        problemStatement1_22.display();
        System.out.println("____________________________________");
        ProblemStatement1_2 problemStatement1_23 = new ProblemStatement1_2();
        problemStatement1_23.input();
        problemStatement1_23.calculate();
        problemStatement1_23.display();
        System.out.println("____________________________________");
        ProblemStatement1_2 problemStatement1_24 = new ProblemStatement1_2();
        problemStatement1_24.input();
        problemStatement1_24.calculate();
        problemStatement1_24.display();
        System.out.println("____________________________________");
        ProblemStatement1_2 problemStatement1_25 = new ProblemStatement1_2();
        problemStatement1_25.input();
        problemStatement1_25.calculate();
        problemStatement1_25.display();
    }
}